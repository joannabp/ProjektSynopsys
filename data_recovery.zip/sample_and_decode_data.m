function [data]=sample_and_decode_data(input_vector, rising_edge_detector, setup, hold, clk);
thresh=0.5;
global min_eye_opening;
global setup_t;
global hold_t;
global unres_val;
vector_length=length(input_vector);

prev_val=0;
k=1;
j=1;
data=[];
sampled=[];
for i=1:vector_length 
    sampled(i)=0;
    if rising_edge_detector(i)==1
        sampled(i)= (input_vector(i)+input_vector(i-1))*abs(clk(i)-thresh-clk(i-1));
    end
end
%-------------------- compare level ----------------%
for i=1:vector_length 
    if rising_edge_detector(i)==1
        %---------- sample 200 ---------------%
            if(setup(j)<setup_t | hold(j)<hold_t)
               data(k:k+1)=unres;
            elseif(sampled(i)>200+min_eye_opening/2)
                data(k:k+1)=1;
            elseif(sampled(i)>200-min_eye_opening/2) 
                 data(k:k+1)=unres;
            elseif(sampled(i)>min_eye_opening/2)
                data(k)=1;
                data(k+1)=0;
            elseif(sampled(i)>-min_eye_opening/2)
                 data(k:k+1)=unres;
            elseif(sampled(i)>-200+min_eye_opening/2) 
                data(k)=0;
                data(k+1)=1;
            elseif(sampled(i)>-200-min_eye_opening/2)
                  data(k:k+1)=unres;
            else 
               data(k:k+1)=0;
            end   
            prev_val=data(j);
             j=j+1;  
             k=k+2;
    end
    if(strcmp(unres_val, 'prev'))
        unres=prev_val;
    else
         unres=unres_val;
    end
end 

