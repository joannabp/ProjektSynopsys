function [setup, hold]=setup_hold_check(input_vector, clk, rising_edge_detector); 
thresh=0.5;
global min_eye_opening;
global setup_t;
global hold_t;
global T;


vector_length=length(input_vector);
% ------------------- check setup time ------------% ---- 
s=1;
prev_val=input_vector(1);
setup(1)=1;
for i=2:vector_length
    c=(input_vector(i)-prev_val);
    if (c<abs(min_eye_opening))
        setup(s)=setup(s)+1;
    else 
        setup(s)=1;
    end
    if(rising_edge_detector(i)==1)
        s=s+1;
        setup(s-1)=setup(s-1)-clk(i)-thresh-clk(i-1);
        setup(s)=1;
    end
    prev_val=input_vector(i);
end
% ------------------- check hold time ------------% ---- 

h=1;
prev_val=input_vector(1);
hold(1)=1;
for i=2:vector_length
    c=(input_vector(i)-prev_val);
    if(rising_edge_detector(i)==1)
        h=h+1;
        hold(h)=clk(i)-thresh-clk(i-1);
        prev_val=input_vector(i);
    end
    if (c<abs(min_eye_opening))
        
        hold(h)=hold(h)+1;
    end
end

setup=setup*T;
hold=hold*T;
